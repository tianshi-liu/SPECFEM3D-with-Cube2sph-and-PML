#!/bin/bash
specfem_dir="${HOME}/code/c_fortran/specfem3d-cube2sph/"
cube2sph_dir=$specfem_dir/utils/cube2sph/
NPROC=2
MPIRUN=mpirun

# # horizontal slice
# NSLICE_HORIZ=2
# DEPTH_H=(10 22.5)  # add more if you want 
# #DEPTH_H=(15)  # add more if you want 
# LON0_H=-0.9; LON1_H=0.9;
# LAT0_H=-0.9; LAT1_H=0.9

# # vertical slice
# NSLICE_VERTI=2
# MAX_DEP=-40

# # start points
# LON0_V=(-0.9  0.2 )
# LAT0_V=(0.0  -0.9 )

# # end points
# LON1_V=(0.9 0.2 )
# LAT1_V=(0.0  0.9 )


# horizontal slice
NSLICE_HORIZ=2
# DEPTH_H=(10 22.5)  # add more if you want 
DEPTH_H=(10 22.5)  # add more if you want, hti 
LON0_H=-0.9; LON1_H=0.9;
LAT0_H=-0.9; LAT1_H=0.9

# vertical slice
NSLICE_VERTI=2
MAX_DEP=40

# tti 
# start points
LON0_V=(-0.9  0.2 )
LAT0_V=(0.0  -0.9 )

# end points
LON1_V=(0.9 0.2 )
LAT1_V=(0.0  0.9 )


# database_dir
DATABASE_DIR=../tomo.3d.30/DATABASES_MPI/
MODEL_DIR=../tomo.3d.30/DATABASES_MPI/

#parameters to interpolate
MODEL_SET="G0 alpha beta kappaa kappab phi rho "
MODEL_SET="alphav alphah betav betah"
MODEL_SET="G0"
KERNEL_SET="dGsp dGcp dalpha dbeta"

# interpolate options
INTP_KL=0 # if =1 interplate models
INTP_LS=0
run_indx=`seq 1 1`

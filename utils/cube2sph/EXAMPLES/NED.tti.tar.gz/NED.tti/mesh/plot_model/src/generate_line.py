import numpy as np
import sys

def latlon_to_cartesian(lat, lon):
    lat_rad = np.radians(lat)
    lon_rad = np.radians(lon)
    x = np.cos(lat_rad) * np.cos(lon_rad)
    y = np.cos(lat_rad) * np.sin(lon_rad)
    z = np.sin(lat_rad)
    return np.array([x, y, z])

def cartesian_to_latlon(x, y, z):
    lat = np.degrees(np.arcsin(z))
    lon = np.degrees(np.arctan2(y, x))
    return lat, lon

def slerp_great_circle(lat1, lon1, lat2, lon2, n):
    """
    Generate n points on the great circle arc between two lat/lon points.

    Parameters:
    -----------
    lat1, lon1 : float
        Latitude and longitude of the first point (degrees)
    lat2, lon2 : float
        Latitude and longitude of the second point (degrees)
    n : int
        Number of points to generate

    Returns:
    --------
    points : list of tuples
        List of (lat, lon) along the great circle
    """
    p0 = latlon_to_cartesian(lat1, lon1)
    p1 = latlon_to_cartesian(lat2, lon2)

    omega = np.arccos(np.clip(np.dot(p0, p1), -1.0, 1.0))
    sin_omega = np.sin(omega)

    if np.isclose(sin_omega, 0):
        # If the points are nearly the same or opposite
        interpolated = np.linspace(p0, p1, n)
    else:
        t = np.linspace(0, 1, n)
        interpolated = (np.sin((1 - t)[:, None] * omega) * p0[None, :] +
                        np.sin(t[:, None] * omega) * p1[None, :]) / sin_omega

    latlon_points = np.zeros((n,2))
    for i in range(interpolated.shape[0]):
        x,y,z = interpolated[i,:]
        latlon_points[i,:] = cartesian_to_latlon(x, y, z)
    return latlon_points

def delsph(lat1,lon1,lat2,lon2):
    R = 6371.0 
    from numpy import sin,cos,sqrt,arctan2

    colatrad1 = np.deg2rad(90 - lat1)
    colatrad2 = np.deg2rad(90 - lat2)
    lonrad1 = np.deg2rad(lon1)
    lonrad2 = np.deg2rad(lon2) 
    dlat = colatrad2 - colatrad1
    dlon = lonrad2 - lonrad1
    lat1rad = np.pi * 0.5 - colatrad1
    lat2rad =  np.pi * 0.5 - colatrad2
    a = sin(dlat * 0.5 ) * sin(dlat * 0.5 ) + sin(dlon * 0.5)  \
        * sin(dlon * 0.5) * cos(lat1rad) * cos(lat2rad)
    c = 2.0 * arctan2(sqrt(a),sqrt(1-a))
    

    return R * c    


def main():
    if len(sys.argv)!=7:
        print("Usage ./this lon1 lon2 lat1 lat2 n outfile")
        exit(1)
    
    lon1,lon2,lat1,lat2 = map(lambda x:float(x),sys.argv[1:5])
    n = int(sys.argv[5])
    outfile = sys.argv[6]
    data = np.zeros((n,3))

    # get points
    data[:,:2] = slerp_great_circle(lat1, lon1, lat2,lon2, n)
    for i in range(n):
        lat,lon = data[i,:2]
        dist = delsph(lat,lon,lat1,lon1)
        data[i,-1] = dist

    # swap 0/1 column
    temp = data[:,0] * 1.
    data[:,0] = data[:,1] * 1.
    data[:,1] = temp * 1.

    np.savetxt(outfile,data,fmt='%f')

if __name__ == "__main__":
    main()

import numpy as np
import matplotlib.pyplot as plt


data_Gs = np.loadtxt("gs.dat")
data_Gc = np.loadtxt("gc.dat")
data_Gsz = np.loadtxt("gsz.dat")
data_Gcz = np.loadtxt("gcz.dat")
data_kappaa = np.loadtxt("kappaa.dat")
data_kappab = np.loadtxt("kappab.dat")
data_kappaa_z = np.loadtxt("kappaa_z.dat")
data_kappab_z = np.loadtxt("kappab_z.dat")
x = np.loadtxt("x.dat") / 1000
y = np.loadtxt("y.dat") / 1000
z = np.loadtxt("z.dat") / 1000
# x = x / np.max(abs(x))
# y = y / np.max(abs(y))
# z = z / np.max(abs(z))

nnx = 2
nny = 2

plt.figure(1,figsize=(15,7))
plt.subplot(1,2,1)
G = np.hypot(data_Gc,data_Gs)
plt.contourf(x,y,G)
plt.colorbar()
plt.title('G0')
plt.xlabel("x,km")
plt.ylabel("y,km")
plt.subplot(1,2,2)
phi = np.arctan2(data_Gs,data_Gc) * 180 / np.pi
plt.contourf(x,y,phi)
plt.colorbar()
plt.title('phi')
plt.xlabel("x,km")
plt.ylabel("y,km")

plt.savefig("ckbd_G0.jpg",dpi=300)

plt.figure(2,figsize=(14,7))
plt.subplot(1,2,1)
G = np.hypot(data_Gcz,data_Gsz)
plt.contourf(x,z,G)
plt.title('G0')
plt.xlabel("x,km")
plt.ylabel("z,km")
plt.colorbar()

plt.subplot(1,2,2)
phi = np.arctan2(data_Gsz,data_Gcz)  * 180 / np.pi
plt.contourf(x,z,phi) 
plt.title('phi')
plt.xlabel("x,km")
plt.ylabel("z,km")
plt.colorbar()

plt.savefig("ckbd_G0.z.jpg")


plt.figure(3,figsize=(15,7))
plt.subplot(1,2,1)
plt.contourf(x,y,data_kappaa)
plt.title('kappaa')
plt.xlabel("x,km")
plt.ylabel("y,km")
plt.colorbar()
plt.subplot(1,2,2)
plt.contourf(x,y,data_kappab)
plt.title('kappab')
plt.xlabel("x,km")
plt.ylabel("y,km")
plt.colorbar() 

plt.savefig("ckbd_kappa.jpg",dpi=300)

plt.figure(4,figsize=(15,7))
plt.subplot(1,2,1)
plt.contourf(x,z,data_kappaa_z)
plt.title('kappaa')
plt.xlabel("x,km")
plt.ylabel("z,km")
plt.colorbar()
plt.subplot(1,2,2)
plt.contourf(x,z,data_kappab_z)
plt.title('kappab')
plt.xlabel("x,km")
plt.ylabel("z,km")
plt.colorbar() 

plt.savefig("ckbd_kappa.z.jpg",dpi=300)
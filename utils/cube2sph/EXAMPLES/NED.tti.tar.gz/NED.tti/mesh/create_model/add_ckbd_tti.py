import numpy as np
from scipy.interpolate import interp1d
from tqdm import tqdm
import matplotlib.pyplot as plt 

def find_loc(x,x0):
    n = len(x)
    dx = x[1] - x[0]

    iloc = int((x0 - x[0]) / dx)

    return iloc


def costaper(n):
    return  0.5 * (1 + np.cos(np.linspace(np.pi, 2 * np.pi, n)))

def add_taper(n,ix1,ix2,ix3,ix4):
    taper = np.zeros((n))
    taper[ix1:ix2+1] = costaper(ix2 - ix1 + 1)
    taper[ix3:ix4 + 1] = costaper(ix4-ix3 + 1)[::-1]
    taper[ix2+1:ix3] = 1.

    return taper


def main():

    # study region
    xmin,xmax = -150000, 150000
    ymin,ymax = -150000, 150000
    zmin,zmax = -40000,0.

    # checkboard start point
    # xmin_ck,xmax_ck = -780000,780000
    # ymin_ck,ymax_ck = -298000,326000
    # zmin_ck = -310000
    xmin_ck,xmax_ck = -100000,100000
    ymin_ck,ymax_ck = -90000,90000
    zmin_ck,zmax_ck = -31000,-0.000

    # size of checkerboard
    cksize_x = 45000
    cksize_y = 35000 * 1.5
    cksize_z = 15000

    # no. of points at each direction
    nx,ny,nz = 121,121,51

    # MAX PERTURBATION for velocity and kappa
    MAX_PER = 0.1
    MAX_PER_KAPPA = 0.05

    # anisotropy
    ANISO = True
    ONLY_AZI_ANISO = False
    MAX_ANISO_PER = 0.03
    BACKGRD = 0.03
    # MAX_ANISO_PER = 0.0
    # BACKGRD = 0.0

    ############# stop here #################


    x = np.linspace(xmin,xmax,nx)
    y = np.linspace(ymin,ymax,ny)
    z = np.linspace(zmin,zmax,nz)
    dx = x[1] - x[0]
    dy = y[1] - y[0]
    dz = z[1] - z[0]
    print("dx dy dz = ",dx,dy,dz)

    # load 1-D model
    data = np.loadtxt("ak135.txt")
    data[:,0] *= 1000

    # create interpolant
    vp_int = interp1d(data[:,0],data[:,1])
    vs_int = interp1d(data[:,0],data[:,2])
    rho_int = interp1d(data[:,0],data[:,3])


    # model
    vs = np.zeros((nz))
    rho = vs * 1.
    vp = vs + 0.
    for iz in range(nz):
        z0 = z[iz]
        vp0 = vp_int(z0)
        vs0 = vs_int(z0)
        rho0 = rho_int(z0)
        vs[iz] = vs0 
        vp[iz] = vp0 
        rho[iz] = rho0 

    # checkerboard size, in zoning
    nx0 = int(cksize_x / dx)
    ny0 = int(cksize_y / dy)
    nz0 = int(cksize_z / dz)
    print(cksize_x,cksize_y,cksize_z)
    print(dx,dy,dz)
    print("checkerboard size in zoning: ",nx0,ny0,nz0)

    # start end index for 
    ix0 = find_loc(x,xmin_ck) + 2
    ix1 = find_loc(x,xmax_ck) - 2
    iy0 = find_loc(y,ymin_ck) + 2
    iy1 = find_loc(y,ymax_ck) - 2
    iz0 = find_loc(z,zmin_ck)
    iz1 = find_loc(z,zmax_ck)

    # determine new ix1/iy1/iz1
    nptx = (ix1 - ix0 + 1) // nx0
    npty = (iy1 - iy0 + 1) // ny0
    nptz = (iz1 - iz0 + 1) // nz0 
    ix0_new = ix0 +  nptx // 2 
    ix1_new = ix0_new + nptx * nx0
    iy0_new = iy0 + npty // 2
    iy1_new = iy0_new + npty * ny0
    iz0_new = iz0 + nptz // 2 
    iz1_new = iz0_new + nptz * nz0
    print(iz0,iz0_new,iz1,iz1_new,nptz,nz0)

    taperx = add_taper(nx,ix0 - 2,ix0_new,ix1_new,ix1 + 2)
    tapery = add_taper(ny,iy0 - 2,iy0_new,iy1_new,iy1 + 2)
    taperz = add_taper(nz,iz0,iz0_new,iz1_new,iz1)
    ix0 = ix0_new
    iy0 = iy0_new
    iz0 = iz0_new

    ix1 = ix1_new
    iy1 = iy1_new
    iz1 = iz1_new
    

    print("checkerboard start/end at x: ",x[ix0],x[ix1])
    print("checkerboard start/end at y: ",y[iy0],y[iy1])
    print("checkerboard start/end at z: ",z[iz0],z[iz1])

    # print(x[ix0],y[iy0],z[iz0])
    # print(x[ix1],y[iy1],z[iz1])

    data_Gs = np.zeros((ny,nx))
    data_Gc = np.zeros((ny,nx))
    data_Gs_z = np.zeros((nz,nx))
    data_Gc_z = np.zeros((nz,nx))
    data_kappaa = np.zeros((ny,nx))
    data_kappaa_z = np.zeros((nz,nx))
    data_kappab = np.zeros((ny,nx))
    data_kappab_z = np.zeros((nz,nx))

    f = open("tomography_model.xyz","w")
    f.write("%f %f %f %f %f %f\n" %(xmin,ymin,zmin,xmax,ymax,zmax))
    f.write("%f %f %f\n" %(dx,dy,dz))
    f.write("%d %d %d\n"%(nx,ny,nz))
    f.write("%f %f %f %f %f %f\n" %(vp.min()*0.9,vp.max()*1.1,vs.min()*0.9,vs.max()*1.1,rho.min()*0.9,rho.max()*1.1))
    for iz in range(nz):
        vp0 = vp[iz]
        vs0 = vs[iz]
        rho0 = rho[iz]
        for iy in range(ny):
            for ix in range(nx):
                f.write("%f %f %f "%(x[ix],y[iy],z[iz]))
                vp1 = vp0 * 1.
                vs1 = vs0 * 1.
                rho1 = rho0 * 1.
                phi = 0
                G = 0.0 
                dv = 0.
                dG = 0.
                dkappa = 0.

                # kappa for vp/vs 
                kappaa = 0.0
                kappab = 0.0

                # checkerboard
                if ix >= ix0 and ix <= ix1 and iy >= iy0 and iy <=iy1 and iz >= iz0 and iz<=iz1:
                    dm = np.sin(np.pi * (ix- ix0)/ nx0) *   \
                        np.sin(np.pi * (iy - iy0) / ny0) * \
                        np.sin(np.pi * (iz - iz0) / nz0)
                    dm_bit = np.sign(dm)

                    # velocity, smooth variation
                    dv = MAX_PER * dm
                    if ONLY_AZI_ANISO:
                        dv = 0.
                    
                    # anisotropy
                    # phi = 30/-30 
                    phi_in_deg = -30 + (1 + dm_bit) / 2 * 60
                    phi = phi_in_deg * np.pi / 180
                    #phi =  -np.pi / 4 + (1 + dm_bit) / 2 * np.pi / 2
                    dG = (1 + dm) / 2

                    # kappa variation
                    dkappa = MAX_PER_KAPPA * dm

                # add taper to perturbation
                tp = taperx[ix] * tapery[iy] * taperz[iz]
                dv = dv * tp 
                dkappa = dkappa * tp

                # add checkerboard to model
                G = BACKGRD + MAX_ANISO_PER * dG #*  abs(dm)
                G = G * tp
                vp1 = vp0 * (1 + dv)
                vs1 = vs0 * (1 + dv)
                rho1 = rho0 * (1 + dv)
                kappaa = dkappa
                kappab = dkappa

                if iz == iz0 + nz0//2:
                    data_Gs[iy,ix] = G * np.sin(phi)
                    data_Gc[iy,ix] = G * np.cos(phi)
                    data_kappaa[iy,ix] = kappaa
                    data_kappab[iy,ix] = kappab
                
                if iy == iy0 + ny0 // 2:
                    data_Gs_z[iz,ix] = G * np.sin(phi)
                    data_Gc_z[iz,ix] = G * np.cos(phi)
                    data_kappaa_z[iz,ix] = kappaa
                    data_kappab_z[iz,ix] = kappab
                if not ANISO:
                    f.write("%f %f %f\n" %(vp1,vs1,rho1))
                else:
                    vpv_sq = 3 * vp1**2 / (2 * (1 + kappaa)**2 + 1)
                    vph_sq = (1 + kappaa)**2 * vpv_sq
                    vsv_sq = 3 * vs1**2 / (2 * (1 + kappab)**2 + 1)
                    vsh_sq = (1 + kappab)**2 * vsv_sq
                    A = vph_sq * rho1
                    C = vpv_sq * rho1
                    AL = vsv_sq * rho1
                    AN = vsh_sq * rho1  
                    F = A - 2 * AL 
                    gs = G * AL * np.sin(2 * phi)
                    gc = G * AL * np.cos(2 * phi)
                    c21 = np.zeros((21))
                    c21[0] = A
                    c21[1] = A - 2.0 * AN
                    c21[2] = F
                    c21[3] = 0.0
                    c21[4] = 0.0
                    c21[5] = 0.0
                    c21[6] = A
                    c21[7] = F
                    c21[8] = 0.0
                    c21[9] = 0.0
                    c21[10] = 0.0
                    c21[11] = C
                    c21[12] = 0.0
                    c21[13] = 0.0
                    c21[14] = 0.0
                    c21[15] = AL - gc
                    c21[16] = -gs
                    c21[17] = 0.0
                    c21[18] = AL + gc 
                    c21[19] = 0.0
                    c21[20] = AN 

                    for j in range(21):
                        f.write("%f " %(c21[j]))
                    f.write("%f\n" %rho1)
    f.close()

    # save txt 
    np.savetxt("x.dat",x,fmt='%g')
    np.savetxt("y.dat",y,fmt='%g')
    np.savetxt("z.dat",z,fmt='%g')
    np.savetxt("gs.dat",data_Gs,fmt='%g')
    np.savetxt("gc.dat",data_Gc,fmt='%g')
    np.savetxt("gsz.dat",data_Gs_z,fmt='%g')
    np.savetxt("gcz.dat",data_Gc_z,fmt='%g')
    np.savetxt("kappaa.dat",data_kappaa,fmt='%g')
    np.savetxt("kappab.dat",data_kappab,fmt='%g')
    np.savetxt("kappaa_z.dat",data_kappaa_z,fmt='%g')
    np.savetxt("kappab_z.dat",data_kappab_z,fmt='%g')

if __name__ == "__main__":
    main()
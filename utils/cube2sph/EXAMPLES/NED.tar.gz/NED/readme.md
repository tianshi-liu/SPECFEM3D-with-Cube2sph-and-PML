# how to use NED-model

## Mesh generation

1. Go to `mesh/create_model`, run:
   - `tomo.py`
   - `add_ckbd_model.py`

   Then copy `tomography_model.xyz` into `mesh/DATA/tomo_files` as:
   - `tomography_model.xyz.1d`
   - `tomography_model.xyz.ckbd`

2. go to `mesh`, and for each `tomography_model.xyz.{tag}` file:
   - Copy it as `DATA/tomo_files/tomography_model.xyz`
   - Run `step1-step2`
   - Save the resulting directories:
     - `DATABASES_MPI`
     - `OUTPUT_FILES`
     
     into a new directory named `tomo.{tag}`.


## full waveform inversion
install `FWAT-cube2sph` into `fwi`, and copy `fwat_params.bak` to `fwat_params`, then do forward simulation (`run_forward.sh`) to generate data from checkerboard model, and run fwi (`run_fwi.sh`)